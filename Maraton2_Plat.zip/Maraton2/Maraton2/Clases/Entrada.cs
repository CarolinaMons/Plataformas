﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maraton2.Clases
{
    class Entrada
    {
        private string nom;
        private double flujo;
        private string nValvulaOut;

        public Entrada()
        {
        }

        public Entrada(string nom, double flujo, string nValvulaOut)
        {
            this.nom= nom ?? throw new ArgumentNullException(nameof(nom));
            this.flujo = flujo;
            this.nValvulaOut = nValvulaOut ?? throw new ArgumentNullException(nameof(nValvulaOut));
        }

        public string Nom { get => nom; set => nom = value; }
        public double Flujo { get => flujo; set => flujo = value; }
        public string NombreValvulaSalida { get => nValvulaOut; set => nValvulaOut = value; }
    }
}
