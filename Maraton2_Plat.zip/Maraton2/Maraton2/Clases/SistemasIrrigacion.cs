﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maraton2.Clases
{
    class SistIrrigacion
    {
        public static bool right = true;
        public static bool left = false;
        private Valvula[] valvula;
        private Entrada[] entradas;
        private Salida[] salidas;
        private ConfiguracionValvulas[] configuraciones;

        internal Valvula[] Valvula { get => valvula; set => valvula = value; }
        internal Entrada[] Entradas { get => entradas; set => entradas = value; }
        internal Salida[] Salidas { get => salidas; set => salidas = value; }
        public ConfiguracionValvulas[] Configuraciones { get => configuraciones; set => configuraciones = value; }

        public SistIrrigacion()
        {
        }

        public SistIrrigacion(string SI)
        {
            string[] aux = SI.Split('+');
            string[] tamaños = aux[0].Split(' ');
            string[] flujos = aux[1].Split(' ');
            entradas = new Entrada[Convert.ToInt32(tamaños[0])];
            salidas = new Salida[Convert.ToInt32(tamaños[1])];
            valvula = new Valvula[Convert.ToInt32(tamaños[2])];
            
            //Se suben la entradas
            for(int i = 2; i < entradas.Length+2; i++)
            {
                string[] entr = aux[i].Split(' ');
                entradas[i - 2] = new Entrada(entr[0], Convert.ToDouble(flujos[i - 2]), entr[1]);
            }
            
            for (int i = 2+ entradas.Length ; i < 2 + entradas.Length+salidas.Length; i++)
            {
                salidas[i - 2 - entradas.Length] = new Salida(aux[i]);
            }
            
            for (int i = 2 + entradas.Length+salidas.Length; i < 2 + entradas.Length + salidas.Length +valvula.Length; i++)
            {
                string[] val = aux[i].Split(' ');
                valvula[i - 2 - entradas.Length - salidas.Length] = new Valvula(val[0], val[1], val[2]);
            }
            configuraciones = new ConfiguracionValvulas[aux.Length - (2 + entradas.Length + salidas.Length + valvula.Length)];
            for (int i = 2 + entradas.Length + salidas.Length+ valvula.Length; i < aux.Length; i++)
            {
                //Console.WriteLine(i - 2 - entradas.Length - salidas.Length - valvulas.Length);
                configuraciones[i - 2 - entradas.Length - salidas.Length - valvula.Length] = new ConfiguracionValvulas(aux[i]);
            }
        }

        public string Imprimir()
        {
            string salida = "";
            foreach(Entrada i in entradas)
            {
                salida +=i.Nom+" "+i.Flujo+" "+i.nValvulaOut+ "\n";
            }
            foreach (Salida i in salidas)
            {
                salida += i.Nom + "\n";
            }
            foreach(Valvula i in valvula)
            {
                salida += i.Nom+ " " + i.ConfRight + " " + i.ConfLeft + "\n";
            }
            foreach(ConfiguracionValvula i in configuraciones)
            {
                salida += i.imprimir()+"\n";
            }

            return salida;
        }

        public string calcularFlujos(int conf)
        {
            if (conf >= 0 && conf < configuraciones.Length)
            {
                string resultado="";
                double[] entr = new double[entradas.Length];
                for (int i = 0; i < entradas.Length; i++)
                {
                    entr[i]= entradas[i].Flujo;
                    foreach (Valvula j in valvula)
                    {
                        if (entradas[i].nValvulaOut.Equals(j.Nombre)) j.Flujo += entradas[i].Flujo;
                    }
                }
                
                
                for (int i = 0; i < valvula.Length; i++)
                {
                    for (int j = 0; j < valvula.Length; j++)
                    {
                        if (configuraciones[conf].ConfiguracionValculas[i] == right)
                        {
                            if (valvula[i].ConfDerecha.Equals(valvula[j].Nom)) valvula[j].Flujo = valvula[i].Flujo;
                            for (int k = 0; k < salidas.Length; k++)
                            {
                                if (valvula[i].ConfDerecha.Equals(salidas[k].Nom)) salidas[k].Flujo = valvula[i].Flujo;
                            }
                        }
                        else if (configuraciones[conf].ConfiguracionValculas[i] == left)
                        {
                            if (valvula[i].ConfIzquierda.Equals(valvula[j].Nom)) valvula[j].Flujo = valvula[i].Flujo;
                            for (int k = 0; k < salidas.Length; k++)
                            {
                                if (valvula[i].ConfDerecha.Equals(salidas[k].Nom)) salidas[k].Flujo = valvula[i].Flujo;
                            }
                        }
                    }
                    foreach (Valvula j in valvula)
                    {
                        Console.Write(j.Flujo + "|");
                    }
                    Console.WriteLine("");
                }

                resultado += "Conf de valvulas " + (conf + 1)+"\n";
                for (int k = 0; k < salidas.Length; k++)
                {
                    resultado += "Salida (" + salidas[k].Nom + ") # " + (k + 1)+" : flujo "+ salidas[k].Flujo+"galones/minuto\n";
                }
                for (int i = 0; i < entradas.Length; i++)entradas[i].Flujo=entr[i] ;
                foreach (Valvula j in valvula)j.Flujo=0;
                foreach (Salida j in salidas) j.Flujo = 0;
                return resultado;

            }
            else return "No exista dicha conf";
        }
    }
}
