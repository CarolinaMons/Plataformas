﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Mercado.Data;
using MercadoCaro.Models;

namespace MercadoCaro.Controllers
{
    public class Mercado1Controller : Controller
    {
        private readonly MercadoCaroContext _context;

        public Mercado1Controller(MercadoCaroContext context)
        {
            _context = context;
        }

        // GET: Mercado1
        public async Task<IActionResult> Index()
        {
            var mercadoCaroContext = _context.Mercado.Include(m => m.Propietario);
            return View(await mercadoCaroContext.ToListAsync());
        }

        // GET: Mercado1/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mercado1 = await _context.Mercado
                .Include(m => m.Propietario)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (mercado1 == null)
            {
                return NotFound();
            }

            return View(mercado1);
        }

        // GET: Mercado1/Create
        public IActionResult Create()
        {
            ViewData["PropietarioId"] = new SelectList(_context.Propietario, "Id", "Id");
            return View();
        }

        // POST: Mercado1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FechaCreacion,PropietarioId,Estado")] Mercado1 mercado1)
        {
            if (ModelState.IsValid)
            {
                _context.Add(mercado1);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PropietarioId"] = new SelectList(_context.Propietario, "Id", "Id", mercado1.PropietarioId);
            return View(mercado1);
        }

        // GET: Mercado1/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mercado1 = await _context.Mercado.FindAsync(id);
            if (mercado1 == null)
            {
                return NotFound();
            }
            ViewData["PropietarioId"] = new SelectList(_context.Propietario, "Id", "Id", mercado1.PropietarioId);
            return View(mercado1);
        }

        // POST: Mercado1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FechaCreacion,PropietarioId,Estado")] Mercado1 mercado1)
        {
            if (id != mercado1.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(mercado1);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Mercado1Exists(mercado1.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PropietarioId"] = new SelectList(_context.Propietario, "Id", "Id", mercado1.PropietarioId);
            return View(mercado1);
        }

        // GET: Mercado1/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mercado1 = await _context.Mercado
                .Include(m => m.Propietario)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (mercado1 == null)
            {
                return NotFound();
            }

            return View(mercado1);
        }

        // POST: Mercado1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var mercado1 = await _context.Mercado.FindAsync(id);
            _context.Mercado.Remove(mercado1);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Mercado1Exists(int id)
        {
            return _context.Mercado.Any(e => e.Id == id);
        }
    }
}
